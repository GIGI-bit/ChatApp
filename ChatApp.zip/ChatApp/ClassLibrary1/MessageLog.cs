﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Threading.Tasks;

namespace ClassLibrary1
{
    public class MessageLog
    {
        public string Reciever {  get; set; }
        public string Sender {  get; set; }//Json-a yazilan zaman seliqeli, log kimi gorsensin deye gonderenin adida qeyd olunub burda.
        public string Message { get; set; }
        public MessageLog(string reciever,string sender,string message) {
        
            Reciever = reciever;
            Sender = sender;
            Message = message;
        }

        public override string ToString()
        {
            return $"Sender: {Sender} \n Reciever: {Reciever} \n Message: {Message}";
        }

    }
}
