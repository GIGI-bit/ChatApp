﻿using ClassLibrary1;
using System.Net;
using System.Net.Sockets;
using System.Reflection.Metadata;
using System.Text.Json;


var ip = IPAddress.Parse("192.168.1.8");
var port = 27000;

var server = new IPEndPoint(ip, port);

var client = new TcpClient();

client.Connect(server);

NetworkStream clientStream = client.GetStream();
BinaryWriter writer = new BinaryWriter(clientStream);
BinaryReader reader = new BinaryReader(clientStream);



_ = Task.Run(() =>
{
    while (true)
    {
        var msg =reader.ReadString();
        var jsonString=JsonSerializer.Deserialize<MessageLog>(msg);
        Console.WriteLine($"One New Message: {jsonString.ToString()}");
    }

});


bool isCheck = false;
string senderName = "";
string recieverName = "";
while (true)
{

    if (!isCheck)
    {
        Console.WriteLine("Enter Your NAme: ");

        senderName = Console.ReadLine();
        writer.Write(senderName);
        isCheck = true;
    }
    else
    {
        Console.WriteLine("Reciever: ");
        recieverName= Console.ReadLine();
        Console.WriteLine("Message: ");
        var msg = Console.ReadLine();
        var ml = new MessageLog(recieverName, senderName, msg);
        var json=JsonSerializer.Serialize(ml);
        writer.Write(json);
    }

  
}
