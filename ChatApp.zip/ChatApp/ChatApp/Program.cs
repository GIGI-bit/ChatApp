﻿using ClassLibrary1;
using System.Net;
using System.Net.Sockets;
using System.Text.Json;

var ip = IPAddress.Parse("192.168.1.8");
var port = 27000;

var listenerEP = new IPEndPoint(ip, port);

using var listener = new TcpListener(listenerEP);
listener.Start();

Console.WriteLine($"{listener.Server.LocalEndPoint} Listener started......");


while (true)
{
    var client = listener.AcceptTcpClient();


    _ = Task.Run(() =>
    {
        var clientStream = client.GetStream();
        var reader = new BinaryReader(clientStream);
        var writer =new BinaryWriter(clientStream);

     
        bool isCheck = false;
        string userName = "";
        string msg = "";
        while (true)
        {
            if (!isCheck)
            {
                userName = reader.ReadString();

                var user = new User();
                user.UserName = userName;
                user.UserData = client;
                DataHolder.Clients.Add(user);
                Console.WriteLine($@"{client.Client.RemoteEndPoint} Name: {userName} Connected.....");
                isCheck = true;
            }

            if (isCheck)
            {
                msg = reader.ReadString();
                MessageLog ml = JsonSerializer.Deserialize<MessageLog>(msg);

                if (ml != null )
                {
                    User newUser = DataHolder.Clients.Find(c => c.UserName.ToLower() == ml.Reciever.ToLower());
                    if(newUser != null )
                    {
                        var newWriter = new BinaryWriter(newUser.UserData.GetStream());
                        var newMsg = new MessageLog(userName, ml.Sender, ml.Message);
                        var json=JsonSerializer.Serialize<MessageLog>(newMsg);
                        newWriter.Write(json);
                    }
                    

                }


            }
        }

    });


}


static class DataHolder
{
    public static List<User> Clients=new List<User>();
}

